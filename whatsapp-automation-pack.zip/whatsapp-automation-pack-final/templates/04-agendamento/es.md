¡Hola [Nombre]!

Confirmo tu cita para:

📅 **Fecha:** [Fecha]
⏰ **Hora:** [Hora]
📍 **Lugar/Plataforma:** [Detalles]
👤 **Con:** [Nombre del Profesional]

**Detalles importantes:**
• Duración: [X] minutos
• Preparación necesaria: [Instrucciones]
• Enlace de acceso: [Enlace - si es online]

📱 **Recordatorios:**
1. Recibirás confirmación por email
2. Recordatorio 24h antes por WhatsApp
3. Para reprogramar/cancelar: responde este mensaje

¡Te esperamos!

Atentamente,
Equipo [Nombre de la Empresa]
