Hello [Name]!

I confirm your appointment for:

📅 **Date:** [Date]
⏰ **Time:** [Time]
📍 **Location/Platform:** [Details]
👤 **With:** [Professional Name]

**Important details:**
• Duration: [X] minutes
• Preparation needed: [Instructions]
• Access link: [Link - if online]

📱 **Reminders:**
1. You'll receive email confirmation
2. 24-hour reminder via WhatsApp
3. To reschedule/cancel: reply to this message

We look forward to seeing you!

Best regards,
[Company Name] Team
