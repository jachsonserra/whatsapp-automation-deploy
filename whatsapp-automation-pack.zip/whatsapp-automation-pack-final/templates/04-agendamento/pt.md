Olá [Nome]!

Confirmo seu agendamento para:

📅 **Data:** [Data]
⏰ **Horário:** [Horário]
📍 **Local/Plataforma:** [Detalhes]
👤 **Com:** [Nome do Profissional]

**Detalhes importantes:**
• Duração: [X] minutos
• Preparação necessária: [Instruções]
• Link de acesso: [Link - se online]

📱 **Lembretes:**
1. Receberá confirmação por email
2. Lembrete 24h antes por WhatsApp
3. Para reagendar/cancelar: responda esta mensagem

Aguardamos você!

Atenciosamente,
Equipe [Nome da Empresa]
