¡Hola [Nombre]!

Gracias por tu pregunta sobre "[Tema de la Pregunta]".

Aquí está la información que necesitas:

[Insertar respuesta clara y concisa]

📌 **Resumen rápido:**
• [Punto 1]
• [Punto 2]
• [Punto 3]

¿Necesitas más detalles? ¡Solo pregúntame!

Para acceder a nuestro FAQ completo: [Enlace]

Atentamente,
Equipo [Nombre de la Empresa]
