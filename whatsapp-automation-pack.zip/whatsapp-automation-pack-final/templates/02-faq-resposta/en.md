Hello [Name]!

Thank you for your question about "[Question Topic]".

Here's the information you need:

[Insert clear and concise answer]

📌 **Quick summary:**
• [Point 1]
• [Point 2]
• [Point 3]

Need more details? Just ask me!

To access our complete FAQ: [Link]

Best regards,
[Company Name] Team
