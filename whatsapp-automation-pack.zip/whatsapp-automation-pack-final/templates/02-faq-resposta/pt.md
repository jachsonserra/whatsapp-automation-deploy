Olá [Nome]!

Obrigado pela sua pergunta sobre "[Assunto da Pergunta]".

Aqui está a informação que precisa:

[Inserir resposta clara e concisa]

📌 **Resumo rápido:**
• [Ponto 1]
• [Ponto 2]
• [Ponto 3]

Precisa de mais detalhes? Basta me perguntar!

Para acessar nosso FAQ completo: [Link]

Atenciosamente,
Equipe [Nome da Empresa]
