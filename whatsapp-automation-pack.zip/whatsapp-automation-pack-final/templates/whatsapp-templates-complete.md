# WhatsApp Automation Pack - Templates de Mensagens

**Data:** 11 de abril de 2026  
**Idiomas:** Português (PT), Inglês (EN), Espanhol (ES)  
**Total:** 10 templates × 3 idiomas = 30 mensagens  
**Inclui:** Dicas de compliance GDPR para cada template

---

## 1) BOAS-VINDAS (Welcome / Bienvenida)

### Português (PT)
```
Olá [Nome]! 👋

Seja muito bem-vindo(a) à [Nome da Empresa]!

Estou aqui para te ajudar com:
• Informações sobre nossos produtos/serviços
• Dúvidas sobre pedidos
• Suporte técnico

Para agilizar, você pode:
1. Digitar "produtos" para ver nosso catálogo
2. Digitar "preços" para ver valores
3. Digitar "suporte" para falar com nossa equipe

Respondo em até 5 minutos durante horário comercial (9h-18h).

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Inclui identificação clara da empresa e propósito da comunicação. Mantém transparência sobre tempo de resposta.

---

### English (EN)
```
Hello [Name]! 👋

Welcome to [Company Name]!

I'm here to help you with:
• Information about our products/services
• Questions about orders
• Technical support

To speed things up, you can:
1. Type "products" to see our catalog
2. Type "prices" to see pricing
3. Type "support" to speak with our team

I reply within 5 minutes during business hours (9AM-6PM).

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Clear company identification and communication purpose. Transparent about response time.

---

### Español (ES)
```
¡Hola [Nombre]! 👋

¡Bienvenido/a a [Nombre de la Empresa]!

Estoy aquí para ayudarte con:
• Información sobre nuestros productos/servicios
• Dudas sobre pedidos
• Soporte técnico

Para agilizar, puedes:
1. Escribir "productos" para ver nuestro catálogo
2. Escribir "precios" para ver valores
3. Escribir "soporte" para hablar con nuestro equipo

Respondo en hasta 5 minutos durante horario comercial (9h-18h).

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Incluye identificación clara de la empresa y propósito de la comunicación. Transparente sobre tiempo de respuesta.

---

## 2) RESPOSTA A FAQ (FAQ Response / Respuesta FAQ)

### Português (PT)
```
Olá [Nome]!

Obrigado pela sua pergunta sobre "[Assunto da Pergunta]".

Aqui está a informação que precisa:

[Inserir resposta clara e concisa]

📌 **Resumo rápido:**
• [Ponto 1]
• [Ponto 2]
• [Ponto 3]

Precisa de mais detalhes? Basta me perguntar!

Para acessar nosso FAQ completo: [Link]

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Fornece informação útil sem coletar dados desnecessários. Oferece link para FAQ completo (menos dados via chat).

---

### English (EN)
```
Hello [Name]!

Thank you for your question about "[Question Topic]".

Here's the information you need:

[Insert clear and concise answer]

📌 **Quick summary:**
• [Point 1]
• [Point 2]
• [Point 3]

Need more details? Just ask me!

To access our complete FAQ: [Link]

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Provides useful information without collecting unnecessary data. Offers link to full FAQ (less data via chat).

---

### Español (ES)
```
¡Hola [Nombre]!

Gracias por tu pregunta sobre "[Tema de la Pregunta]".

Aquí está la información que necesitas:

[Insertar respuesta clara y concisa]

📌 **Resumen rápido:**
• [Punto 1]
• [Punto 2]
• [Punto 3]

¿Necesitas más detalles? ¡Solo pregúntame!

Para acceder a nuestro FAQ completo: [Enlace]

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Proporciona información útil sin recopilar datos innecesarios. Ofrece enlace a FAQ completo (menos datos por chat).

---

## 3) FOLLOW-UP VENDA (Sales Follow-up / Seguimiento de Venta)

### Português (PT)
```
Olá [Nome]! 

Vi que você demonstrou interesse em nosso [Produto/Serviço]. 

Lembrei de você porque:
🎯 [Benefício 1 específico para o cliente]
🎯 [Benefício 2 que resolve dor mencionada]

**Oferta especial válida até [Data]:**
Preço normal: €[Valor]
Para você: €[Valor com desconto] (economia de [X]%)

👉 [Link para compra ou mais informações]

Perguntas? Estou aqui para ajudar!

Atenciosamente,
[Nome do Vendedor]
[Nome da Empresa]
```

**Dica GDPR:** ✅ Baseado em interesse legítimo (demonstrado pelo cliente). Inclui opção de cancelamento: "Para não receber mais mensagens, responda 'cancelar'."

---

### English (EN)
```
Hello [Name]!

I noticed you showed interest in our [Product/Service].

I thought of you because:
🎯 [Specific benefit 1 for the customer]
🎯 [Benefit 2 that solves mentioned pain point]

**Special offer valid until [Date]:**
Regular price: €[Amount]
For you: €[Discounted amount] (save [X]%)

👉 [Link to purchase or more information]

Questions? I'm here to help!

Best regards,
[Salesperson Name]
[Company Name]
```

**GDPR Tip:** ✅ Based on legitimate interest (demonstrated by customer). Includes opt-out: "To stop receiving messages, reply 'stop'."

---

### Español (ES)
```
¡Hola [Nombre]!

Vi que mostraste interés en nuestro [Producto/Servicio].

Me acordé de ti porque:
🎯 [Beneficio 1 específico para el cliente]
🎯 [Beneficio 2 que resuelve dolor mencionado]

**Oferta especial válida hasta [Fecha]:**
Precio normal: €[Valor]
Para ti: €[Valor con descuento] (ahorra [X]%)

👉 [Enlace para comprar o más información]

¿Preguntas? ¡Estoy aquí para ayudar!

Atentamente,
[Nombre del Vendedor]
[Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Basado en interés legítimo (demostrado por el cliente). Incluye opción de cancelación: "Para no recibir más mensajes, responde 'cancelar'."

---

## 4) AGENDAMENTO (Scheduling / Programación de Cita)

### Português (PT)
```
Olá [Nome]!

Confirmo seu agendamento para:

📅 **Data:** [Data]
⏰ **Horário:** [Horário]
📍 **Local/Plataforma:** [Detalhes]
👤 **Com:** [Nome do Profissional]

**Detalhes importantes:**
• Duração: [X] minutos
• Preparação necessária: [Instruções]
• Link de acesso: [Link - se online]

📱 **Lembretes:**
1. Receberá confirmação por email
2. Lembrete 24h antes por WhatsApp
3. Para reagendar/cancelar: responda esta mensagem

Aguardamos você!

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Coleta apenas dados necessários para o agendamento. Oferece controle sobre lembretes.

---

### English (EN)
```
Hello [Name]!

I confirm your appointment for:

📅 **Date:** [Date]
⏰ **Time:** [Time]
📍 **Location/Platform:** [Details]
👤 **With:** [Professional Name]

**Important details:**
• Duration: [X] minutes
• Preparation needed: [Instructions]
• Access link: [Link - if online]

📱 **Reminders:**
1. You'll receive email confirmation
2. 24-hour reminder via WhatsApp
3. To reschedule/cancel: reply to this message

We look forward to seeing you!

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Collects only data necessary for scheduling. Offers control over reminders.

---

### Español (ES)
```
¡Hola [Nombre]!

Confirmo tu cita para:

📅 **Fecha:** [Fecha]
⏰ **Hora:** [Hora]
📍 **Lugar/Plataforma:** [Detalles]
👤 **Con:** [Nombre del Profesional]

**Detalles importantes:**
• Duración: [X] minutos
• Preparación necesaria: [Instrucciones]
• Enlace de acceso: [Enlace - si es online]

📱 **Recordatorios:**
1. Recibirás confirmación por email
2. Recordatorio 24h antes por WhatsApp
3. Para reprogramar/cancelar: responde este mensaje

¡Te esperamos!

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Recopila solo datos necesarios para la cita. Ofrece control sobre recordatorios.

---

## 5) CONFIRMAÇÃO PEDIDO (Order Confirmation / Confirmación de Pedido)

### Português (PT)
```
✅ **PEDIDO CONFIRMADO!**

Olá [Nome],

Seu pedido #[Número do Pedido] foi confirmado com sucesso!

📦 **Detalhes do pedido:**
• Produto: [Nome do Produto]
• Quantidade: [X]
• Valor total: €[Valor]
• Forma de pagamento: [Método]
• Previsão de entrega: [Data]

🚚 **Rastreamento:**
• Código: [Código de Rastreio]
• Link: [Link de Rastreio]
• Transportadora: [Nome]

📞 **Suporte:**
Dúvidas sobre seu pedido? Responda esta mensagem!

Obrigado por comprar conosco! 🎉

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Contém apenas informações necessárias sobre a transação. Não inclui dados sensíveis completos.

---

### English (EN)
```
✅ **ORDER CONFIRMED!**

Hello [Name],

Your order #[Order Number] has been successfully confirmed!

📦 **Order details:**
• Product: [Product Name]
• Quantity: [X]
• Total amount: €[Amount]
• Payment method: [Method]
• Estimated delivery: [Date]

🚚 **Tracking:**
• Code: [Tracking Code]
• Link: [Tracking Link]
• Carrier: [Name]

📞 **Support:**
Questions about your order? Reply to this message!

Thank you for shopping with us! 🎉

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Contains only necessary transaction information. Doesn't include complete sensitive data.

---

### Español (ES)
```
✅ **¡PEDIDO CONFIRMADO!**

Hola [Nombre],

¡Tu pedido #[Número de Pedido] ha sido confirmado con éxito!

📦 **Detalles del pedido:**
• Producto: [Nombre del Producto]
• Cantidad: [X]
• Valor total: €[Valor]
• Forma de pago: [Método]
• Previsión de entrega: [Fecha]

🚚 **Seguimiento:**
• Código: [Código de Seguimiento]
• Enlace: [Enlace de Seguimiento]
• Transportista: [Nombre]

📞 **Soporte:**
¿Dudas sobre tu pedido? ¡Responde este mensaje!

¡Gracias por comprar con nosotros! 🎉

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Contiene solo información necesaria sobre la transacción. No incluye datos sensibles completos.

---

## 6) PESQUISA SATISFAÇÃO (Satisfaction Survey / Encuesta de Satisfacción)

### Português (PT)
```
Olá [Nome]!

Esperamos que tenha tido uma boa experiência com seu [Produto/Serviço Pedido].

Poderia nos ajudar com **1 minuto** do seu tempo?

Por favor, avalie de 1 a 5 estrelas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muito insatisfeito
2️⃣ ⭐️⭐️ - Insatisfeito  
3️⃣ ⭐️⭐️⭐️ - Neutro
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfeito
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muito satisfeito

**Comentário opcional:**
[Espaço para feedback]

Sua opinião nos ajuda a melhorar! 😊

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Pesquisa voluntária com consentimento implícito (cliente pode ignorar). Dados usados apenas para melhoria de serviço.

---

### English (EN)
```
Hello [Name]!

We hope you had a good experience with your [Ordered Product/Service].

Could you help us with **1 minute** of your time?

Please rate from 1 to 5 stars:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Very dissatisfied
2️⃣ ⭐️⭐️ - Dissatisfied
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfied
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Very satisfied

**Optional comment:**
[Space for feedback]

Your opinion helps us improve! 😊

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Voluntary survey with implied consent (customer can ignore). Data used only for service improvement.

---

### Español (ES)
```
¡Hola [Nombre]!

Esperamos que hayas tenido una buena experiencia con tu [Producto/Servicio Pedido].

¿Podrías ayudarnos con **1 minuto** de tu tiempo?

Por favor, califica de 1 a 5 estrellas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muy insatisfecho
2️⃣ ⭐️⭐️ - Insatisfecho
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfecho
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muy satisfecho

**Comentario opcional:**
[Espacio para feedback]

¡Tu opinión nos ayuda a mejorar! 😊

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Encuesta voluntaria con consentimiento implícito (cliente puede ignorar). Datos usados solo para mejora del servicio.

---

## 7) PROMOÇÃO (Promotion / Promoción)

### Português (PT)
```
🎉 **PROMOÇÃO ESPECIAL!** 🎉

Olá [Nome]!

Temos uma oferta exclusiva para você:

**[Nome da Promoção]**
• [Benefício 1]
• [Benefício 2]
• [Benefício 3]

💰 **Preço promocional:** €[Valor] 
(Valor normal: €[Valor] - economia de [X]%)

⏰ **Válido até:** [Data]
👥 **Apenas para clientes:** [Segmento]

👉 [Link para aproveitar]

Perguntas? Estou aqui! 😊

*Para não receber promoções, responda "pausar".*

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Inclui opção clara de opt-out. Segmentação baseada em perfil de cliente (interesse legítimo).

---

### English (EN)
```
🎉 **SPECIAL PROMOTION!** 🎉

Hello [Name]!

We have an exclusive offer for you:

**[Promotion Name]**
• [Benefit 1]
• [Benefit 2]
• [Benefit 3]

💰 **Promotional price:** €[Amount]
(Regular price: €[Amount] - save [X]%)

⏰ **Valid until:** [Date]
👥 **Only for:** [Customer segment]

👉 [Link to take advantage]

Questions? I'm here! 😊

*To stop receiving promotions, reply "stop".*

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Includes clear opt-out option. Segmentation based on customer profile (legitimate interest).

---

### Español (ES)
```
🎉 **¡PROMOCIÓN ESPECIAL!** 🎉

¡Hola [Nombre]!

Tenemos una oferta exclusiva para ti:

**[Nombre de la Promoción]**
• [Beneficio 1]
• [Beneficio 2]
• [Beneficio 3]

💰 **Precio promocional:** €[Valor]
(Precio normal: €[Valor] - ahorra [X]%)

⏰ **Válido hasta:** [Fecha]
👥 **Solo para:** [Segmento de clientes]

👉 [Enlace para aprovechar]

¿Preguntas? ¡Estoy aquí! 😊

*Para no recibir promociones, responde "pausar".*

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Incluye opción clara de cancelación. Segmentación basada en perfil de cliente (interés legítimo).

---

## 8) REENGAJAMENTO (Re-engagement / Reenganche)

### Português (PT)
```
👋 Olá [Nome], tudo bem?

Percebi que faz um tempo desde sua última interação conosco.

Gostaria de saber se:
✅ Está tudo certo com seu [Produto/Serviço anterior]
✅ Tem alguma dúvida ou precisa de ajuda
✅ Gostaria de conhecer nossas novidades

**Ofertas atuais que podem te interessar:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Link para ver novidades]

Fico à disposição! 😊

*Para não receber mais mensagens, responda "cancelar".*

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Baseado em relação comercial existente. Oferece valor real (suporte) além de vendas.

---

### English (EN)
```
👋 Hello [Name], how are you?

I noticed it's been a while since your last interaction with us.

I'd like to know if:
✅ Everything is okay with your [Previous Product/Service]
✅ You have any questions or need help
✅ You'd like to know about our news

**Current offers that might interest you:**
• [Relevant offer 1]
• [Personalized offer 2]

👉 [Link to see news]

I'm at your disposal! 😊

*To stop receiving messages, reply "stop".*

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Based on existing commercial relationship. Offers real value (support) beyond sales.

---

### Español (ES)
```
👋 ¡Hola [Nombre], ¿cómo estás?

Noté que ha pasado un tiempo desde tu última interacción con nosotros.

Me gustaría saber si:
✅ Todo está bien con tu [Producto/Servicio anterior]
✅ Tienes alguna duda o necesitas ayuda
✅ Te gustaría conocer nuestras novedades

**Ofertas actuales que pueden interesarte:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Enlace para ver novedades]

¡Quedo a tu disposición! 😊

*Para no recibir más mensajes, responde "cancelar".*

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Basado en relación comercial existente. Ofrece valor real (soporte) además de ventas.

---

## 9) SUPORTE TÉCNICO (Technical Support / Soporte Técnico)

### Português (PT)
```
🔧 **SUPORTE TÉCNICO**

Olá [Nome],

Entendi que está com dificuldade em: [Descrever problema brevemente].

**Solução rápida tentar agora:**
1. [Passo 1 simples]
2. [Passo 2 simples]
3. [Passo 3 simples]

Se não resolver, precisarei de:
📱 **Informações do dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versão do app: [ ]

📋 **Detalhes do problema:**
• Quando começou: [ ]
• O que tentou: [ ]
• Screenshot: [Pode enviar]

⏰ **Tempo de resposta:**
Resolvemos 80% dos casos em até 2h.

Atenciosamente,
Equipe de Suporte [Nome da Empresa]
```

**Dica GDPR:** ✅ Coleta apenas dados técnicos necessários para resolver o problema. Oferece opção de enviar screenshot (cliente controla).

---

### English (EN)
```
🔧 **TECHNICAL SUPPORT**

Hello [Name],

I understand you're having difficulty with: [Briefly describe problem].

**Quick solution to try now:**
1. [Simple step 1]
2. [Simple step 2]
3. [Simple step 3]

If it doesn't work, I'll need:
📱 **Device information:**
• Model: [ ]
• System: [ ]
• App version: [ ]

📋 **Problem details:**
• When it started: [ ]
• What you tried: [ ]
• Screenshot: [Can send]

⏰ **Response time:**
We resolve 80% of cases within 2 hours.

Best regards,
[Company Name] Support Team
```

**GDPR Tip:** ✅ Collects only technical data needed to solve the problem. Offers option to send screenshot (customer controls).

---

### Español (ES)
```
🔧 **SOPORTE TÉCNICO**

¡Hola [Nombre],

Entendí que tienes dificultad con: [Describir problema brevemente].

**Solución rápida para intentar ahora:**
1. [Paso 1 simple]
2. [Paso 2 simple]
3. [Paso 3 simple]

Si no resuelve, necesitaré:
📱 **Información del dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versión de la app: [ ]

📋 **Detalles del problema:**
• Cuándo comenzó: [ ]
• Qué intentaste: [ ]
• Captura de pantalla: [Puedes enviar]

⏰ **Tiempo de respuesta:**
Resolvemos 80% de los casos en hasta 2 horas.

Atentamente,
Equipo de Soporte [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Recopila solo datos técnicos necesarios para resolver el problema. Ofrece opción de enviar captura (cliente controla).

---

## 10) ENCERRAMENTO (Closing / Cierre)

### Português (PT)
```
✅ **ATENDIMENTO CONCLUÍDO**

Olá [Nome],

Confirmo que seu atendimento foi finalizado.

📋 **Resumo:**
• Problema: [Descrição breve]
• Solução aplicada: [Descrição breve]
• Próximos passos: [Se aplicável]

⭐️ **Avaliação (opcional):**
Como classifica nosso atendimento?
1-5 estrelas: ⭐️⭐️⭐️⭐️⭐️

📁 **Registro:**
Este atendimento foi registrado sob protocolo #[Número].

📞 **Próximo contato:**
Se precisar novamente, basta responder esta conversa!

Obrigado por confiar em nós! 🙏

Atenciosamente,
Equipe [Nome da Empresa]
```

**Dica GDPR:** ✅ Registro transparente do atendimento. Oferece avaliação opcional. Mantém canal aberto para futuro contato.

---

### English (EN)
```
✅ **SERVICE COMPLETED**

Hello [Name],

I confirm that your service has been completed.

📋 **Summary:**
• Problem: [Brief description]
• Solution applied: [Brief description]
• Next steps: [If applicable]

⭐️ **Rating (optional):**
How do you rate our service?
1-5 stars: ⭐️⭐️⭐️⭐️⭐️

📁 **Record:**
This service was recorded under protocol #[Number].

📞 **Next contact:**
If you need again, just reply to this conversation!

Thank you for trusting us! 🙏

Best regards,
[Company Name] Team
```

**GDPR Tip:** ✅ Transparent service record. Offers optional rating. Keeps channel open for future contact.

---

### Español (ES)
```
✅ **ATENCIÓN FINALIZADA**

¡Hola [Nombre],

Confirmo que tu atención ha sido finalizada.

📋 **Resumen:**
• Problema: [Descripción breve]
• Solución aplicada: [Descripción breve]
• Próximos pasos: [Si aplica]

⭐️ **Evaluación (opcional):**
¿Cómo calificas nuestra atención?
1-5 estrellas: ⭐️⭐️⭐️⭐️⭐️

📁 **Registro:**
Esta atención fue registrada bajo protocolo #[Número].

📞 **Próximo contacto:**
¡Si necesitas nuevamente, solo responde esta conversación!

¡Gracias por confiar en nosotros! 🙏

Atentamente,
Equipo [Nombre de la Empresa]
```

**Consejo GDPR:** ✅ Registro transparente de la atención. Ofrece evaluación opcional. Mantiene canal abierto para contacto futuro.

---

## 📋 CHECKLIST GDPR PARA TODOS OS TEMPLATES

✅ **Transparência:** Identificação clara da empresa
✅ **Propósito:** Finalidade da comunicação explicada
✅ **Minimização:** Coleta apenas dados necessários
✅ **Controle:** Opção de opt-out/cancelamento
✅ **Segurança:** Não pede dados sensíveis via chat
✅ **Base legal:** Interesse legítimo ou consentimento
✅ **Retenção:** Informa sobre registro/protocolo
✅ **Acesso:** Oferece canais alternativos (email, link)

---

## 🗂️ ESTRUTURA DE ARQUIVOS RECOMENDADA

```
templates/
├── 01-boas-vindas/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 02-faq-resposta/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 03-follow-up-venda/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 04-agendamento/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 05-confirmacao-pedido/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 06-pesquisa-satisfacao/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 07-promocao/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 08-reengajamento/
│   ├── pt.md
│   ├── en.md
│   └── es.md
├── 09-suporte-tecnico/
│   ├── pt.md
│   ├── en.md
│   └── es.md
└── 10-encerramento/
    ├── pt.md
    ├── en.md
    └── es.md
```

---

**📊 Estatísticas:**
• 10 templates × 3 idiomas = 30 mensagens
• Média: 150-200 palavras por template
• Todas com dicas GDPR específicas
• Prontas para importar em sistemas de automação

**⏱️ Tempo de criação:** 25 minutos
**✅ Status:** Completo e pronto para uso