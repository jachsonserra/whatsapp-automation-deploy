✅ **¡PEDIDO CONFIRMADO!**

Hola [Nombre],

¡Tu pedido #[Número de Pedido] ha sido confirmado con éxito!

📦 **Detalles del pedido:**
• Producto: [Nombre del Producto]
• Cantidade: [X]
• Valor total: €[Valor]
• Forma de pago: [Método]
• Previsión de entrega: [Fecha]

🚚 **Seguimiento:**
• Código: [Código de Seguimiento]
• Enlace: [Enlace de Seguimiento]
• Transportista: [Nombre]

📞 **Soporte:**
¿Dudas sobre tu pedido? ¡Responde este mensaje!

¡Gracias por comprar con nosotros! 🎉

Atentamente,
Equipo [Nombre de la Empresa]
