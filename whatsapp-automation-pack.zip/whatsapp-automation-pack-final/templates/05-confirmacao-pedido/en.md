✅ **ORDER CONFIRMED!**

Hello [Name],

Your order #[Order Number] has been successfully confirmed!

📦 **Order details:**
• Product: [Product Name]
• Quantity: [X]
• Total amount: €[Amount]
• Payment method: [Method]
• Estimated delivery: [Date]

🚚 **Tracking:**
• Code: [Tracking Code]
• Link: [Tracking Link]
• Carrier: [Name]

📞 **Support:**
Questions about your order? Reply to this message!

Thank you for shopping with us! 🎉

Best regards,
[Company Name] Team
