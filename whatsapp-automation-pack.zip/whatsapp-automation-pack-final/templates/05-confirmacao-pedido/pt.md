✅ **PEDIDO CONFIRMADO!**

Olá [Nome],

Seu pedido #[Número do Pedido] foi confirmado com sucesso!

📦 **Detalhes do pedido:**
• Produto: [Nome do Produto]
• Quantidade: [X]
• Valor total: €[Valor]
• Forma de pagamento: [Método]
• Previsão de entrega: [Data]

🚚 **Rastreamento:**
• Código: [Código de Rastreio]
• Link: [Link de Rastreio]
• Transportadora: [Nome]

📞 **Suporte:**
Dúvidas sobre seu pedido? Responda esta mensagem!

Obrigado por comprar conosco! 🎉

Atenciosamente,
Equipe [Nome da Empresa]
