¡Hola [Nombre]!

Esperamos que hayas tenido una buena experiencia con tu [Producto/Servicio Pedido].

¿Podrías ayudarnos con **1 minuto** de tu tiempo?

Por favor, califica de 1 a 5 estrellas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muy insatisfecho
2️⃣ ⭐️⭐️ - Insatisfecho
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfecho
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muy satisfecho

**Comentario opcional:**
[Espacio para feedback]

¡Tu opinión nos ayuda a mejorar! 😊

Atentamente,
Equipo [Nombre de la Empresa]
