Hello [Name]!

We hope you had a good experience with your [Ordered Product/Service].

Could you help us with **1 minute** of your time?

Please rate from 1 to 5 stars:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Very dissatisfied
2️⃣ ⭐️⭐️ - Dissatisfied
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfied
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Very satisfied

**Optional comment:**
[Space for feedback]

Your opinion helps us improve! 😊

Best regards,
[Company Name] Team
