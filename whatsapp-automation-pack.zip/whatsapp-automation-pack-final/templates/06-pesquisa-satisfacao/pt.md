Olá [Nome]!

Esperamos que tenha tido uma boa experiência com seu [Produto/Serviço Pedido].

Poderia nos ajudar com **1 minuto** do seu tempo?

Por favor, avalie de 1 a 5 estrelas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muito insatisfeito
2️⃣ ⭐️⭐️ - Insatisfeito  
3️⃣ ⭐️⭐️⭐️ - Neutro
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfeito
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muito satisfeito

**Comentário opcional:**
[Espaço para feedback]

Sua opinião nos ajuda a melhorar! 😊

Atenciosamente,
Equipe [Nome da Empresa]
