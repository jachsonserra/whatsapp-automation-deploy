¡Hola [Nombre]! 👋

¡Bienvenido/a a [Nombre de la Empresa]!

Estoy aquí para ayudarte con:
• Información sobre nuestros productos/servicios
• Dudas sobre pedidos
• Soporte técnico

Para agilizar, puedes:
1. Escribir "productos" para ver nuestro catálogo
2. Escribir "precios" para ver valores
3. Escribir "soporte" para hablar con nuestro equipo

Respondo en hasta 5 minutos durante horario comercial (9h-18h).

Atentamente,
Equipo [Nombre de la Empresa]
