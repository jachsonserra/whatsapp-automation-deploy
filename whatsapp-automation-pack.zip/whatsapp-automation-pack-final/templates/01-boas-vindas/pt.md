Olá [Nome]! 👋

Seja muito bem-vindo(a) à [Nome da Empresa]!

Estou aqui para te ajudar com:
• Informações sobre nossos produtos/serviços
• Dúvidas sobre pedidos
• Suporte técnico

Para agilizar, você pode:
1. Digitar "produtos" para ver nosso catálogo
2. Digitar "preços" para ver valores
3. Digitar "suporte" para falar com nossa equipe

Respondo em até 5 minutos durante horário comercial (9h-18h).

Atenciosamente,
Equipe [Nome da Empresa]
