Hello [Name]! 👋

Welcome to [Company Name]!

I'm here to help you with:
• Information about our products/services
• Questions about orders
• Technical support

To speed things up, you can:
1. Type "products" to see our catalog
2. Type "prices" to see pricing
3. Type "support" to speak with our team

I reply within 5 minutes during business hours (9AM-6PM).

Best regards,
[Company Name] Team
