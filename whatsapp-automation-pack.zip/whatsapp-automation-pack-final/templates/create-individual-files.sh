#!/bin/bash

# Script para criar arquivos individuais a partir do arquivo completo
# Execute: bash create-individual-files.sh

echo "Criando arquivos individuais de templates..."

# Template 1: Boas-vindas
cat > 01-boas-vindas/pt.md << 'EOF'
Olá [Nome]! 👋

Seja muito bem-vindo(a) à [Nome da Empresa]!

Estou aqui para te ajudar com:
• Informações sobre nossos produtos/serviços
• Dúvidas sobre pedidos
• Suporte técnico

Para agilizar, você pode:
1. Digitar "produtos" para ver nosso catálogo
2. Digitar "preços" para ver valores
3. Digitar "suporte" para falar com nossa equipe

Respondo em até 5 minutos durante horário comercial (9h-18h).

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 01-boas-vindas/en.md << 'EOF'
Hello [Name]! 👋

Welcome to [Company Name]!

I'm here to help you with:
• Information about our products/services
• Questions about orders
• Technical support

To speed things up, you can:
1. Type "products" to see our catalog
2. Type "prices" to see pricing
3. Type "support" to speak with our team

I reply within 5 minutes during business hours (9AM-6PM).

Best regards,
[Company Name] Team
EOF

cat > 01-boas-vindas/es.md << 'EOF'
¡Hola [Nombre]! 👋

¡Bienvenido/a a [Nombre de la Empresa]!

Estoy aquí para ayudarte con:
• Información sobre nuestros productos/servicios
• Dudas sobre pedidos
• Soporte técnico

Para agilizar, puedes:
1. Escribir "productos" para ver nuestro catálogo
2. Escribir "precios" para ver valores
3. Escribir "soporte" para hablar con nuestro equipo

Respondo en hasta 5 minutos durante horario comercial (9h-18h).

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 1 criado: Boas-vindas"

# Template 2: FAQ Resposta
cat > 02-faq-resposta/pt.md << 'EOF'
Olá [Nome]!

Obrigado pela sua pergunta sobre "[Assunto da Pergunta]".

Aqui está a informação que precisa:

[Inserir resposta clara e concisa]

📌 **Resumo rápido:**
• [Ponto 1]
• [Ponto 2]
• [Ponto 3]

Precisa de mais detalhes? Basta me perguntar!

Para acessar nosso FAQ completo: [Link]

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 02-faq-resposta/en.md << 'EOF'
Hello [Name]!

Thank you for your question about "[Question Topic]".

Here's the information you need:

[Insert clear and concise answer]

📌 **Quick summary:**
• [Point 1]
• [Point 2]
• [Point 3]

Need more details? Just ask me!

To access our complete FAQ: [Link]

Best regards,
[Company Name] Team
EOF

cat > 02-faq-resposta/es.md << 'EOF'
¡Hola [Nombre]!

Gracias por tu pregunta sobre "[Tema de la Pregunta]".

Aquí está la información que necesitas:

[Insertar respuesta clara y concisa]

📌 **Resumen rápido:**
• [Punto 1]
• [Punto 2]
• [Punto 3]

¿Necesitas más detalles? ¡Solo pregúntame!

Para acceder a nuestro FAQ completo: [Enlace]

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 2 criado: FAQ Resposta"

# Template 3: Follow-up Venda
cat > 03-follow-up-venda/pt.md << 'EOF'
Olá [Nome]! 

Vi que você demonstrou interesse em nosso [Produto/Serviço]. 

Lembrei de você porque:
🎯 [Benefício 1 específico para o cliente]
🎯 [Benefício 2 que resolve dor mencionada]

**Oferta especial válida até [Data]:**
Preço normal: €[Valor]
Para você: €[Valor com desconto] (economia de [X]%)

👉 [Link para compra ou mais informações]

Perguntas? Estou aqui para ajudar!

Atenciosamente,
[Nome do Vendedor]
[Nome da Empresa]
EOF

cat > 03-follow-up-venda/en.md << 'EOF'
Hello [Name]!

I noticed you showed interest in our [Product/Service].

I thought of you because:
🎯 [Specific benefit 1 for the customer]
🎯 [Benefit 2 that solves mentioned pain point]

**Special offer valid until [Date]:**
Regular price: €[Amount]
For you: €[Discounted amount] (save [X]%)

👉 [Link to purchase or more information]

Questions? I'm here to help!

Best regards,
[Salesperson Name]
[Company Name]
EOF

cat > 03-follow-up-venda/es.md << 'EOF'
¡Hola [Nombre]!

Vi que mostraste interés en nuestro [Producto/Servicio].

Me acordé de ti porque:
🎯 [Beneficio 1 específico para el cliente]
🎯 [Beneficio 2 que resuelve dolor mencionado]

**Oferta especial válida hasta [Fecha]:**
Precio normal: €[Valor]
Para ti: €[Valor con descuento] (ahorra [X]%)

👉 [Enlace para comprar o más información]

¿Preguntas? ¡Estoy aquí para ayudar!

Atentamente,
[Nombre del Vendedor]
[Nombre de la Empresa]
EOF

echo "✅ Template 3 criado: Follow-up Venda"

# Template 4: Agendamento
cat > 04-agendamento/pt.md << 'EOF'
Olá [Nome]!

Confirmo seu agendamento para:

📅 **Data:** [Data]
⏰ **Horário:** [Horário]
📍 **Local/Plataforma:** [Detalhes]
👤 **Com:** [Nome do Profissional]

**Detalhes importantes:**
• Duração: [X] minutos
• Preparação necessária: [Instruções]
• Link de acesso: [Link - se online]

📱 **Lembretes:**
1. Receberá confirmação por email
2. Lembrete 24h antes por WhatsApp
3. Para reagendar/cancelar: responda esta mensagem

Aguardamos você!

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 04-agendamento/en.md << 'EOF'
Hello [Name]!

I confirm your appointment for:

📅 **Date:** [Date]
⏰ **Time:** [Time]
📍 **Location/Platform:** [Details]
👤 **With:** [Professional Name]

**Important details:**
• Duration: [X] minutes
• Preparation needed: [Instructions]
• Access link: [Link - if online]

📱 **Reminders:**
1. You'll receive email confirmation
2. 24-hour reminder via WhatsApp
3. To reschedule/cancel: reply to this message

We look forward to seeing you!

Best regards,
[Company Name] Team
EOF

cat > 04-agendamento/es.md << 'EOF'
¡Hola [Nombre]!

Confirmo tu cita para:

📅 **Fecha:** [Fecha]
⏰ **Hora:** [Hora]
📍 **Lugar/Plataforma:** [Detalles]
👤 **Con:** [Nombre del Profesional]

**Detalles importantes:**
• Duración: [X] minutos
• Preparación necesaria: [Instrucciones]
• Enlace de acceso: [Enlace - si es online]

📱 **Recordatorios:**
1. Recibirás confirmación por email
2. Recordatorio 24h antes por WhatsApp
3. Para reprogramar/cancelar: responde este mensaje

¡Te esperamos!

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 4 criado: Agendamento"

# Template 5: Confirmação Pedido
cat > 05-confirmacao-pedido/pt.md << 'EOF'
✅ **PEDIDO CONFIRMADO!**

Olá [Nome],

Seu pedido #[Número do Pedido] foi confirmado com sucesso!

📦 **Detalhes do pedido:**
• Produto: [Nome do Produto]
• Quantidade: [X]
• Valor total: €[Valor]
• Forma de pagamento: [Método]
• Previsão de entrega: [Data]

🚚 **Rastreamento:**
• Código: [Código de Rastreio]
• Link: [Link de Rastreio]
• Transportadora: [Nome]

📞 **Suporte:**
Dúvidas sobre seu pedido? Responda esta mensagem!

Obrigado por comprar conosco! 🎉

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 05-confirmacao-pedido/en.md << 'EOF'
✅ **ORDER CONFIRMED!**

Hello [Name],

Your order #[Order Number] has been successfully confirmed!

📦 **Order details:**
• Product: [Product Name]
• Quantity: [X]
• Total amount: €[Amount]
• Payment method: [Method]
• Estimated delivery: [Date]

🚚 **Tracking:**
• Code: [Tracking Code]
• Link: [Tracking Link]
• Carrier: [Name]

📞 **Support:**
Questions about your order? Reply to this message!

Thank you for shopping with us! 🎉

Best regards,
[Company Name] Team
EOF

cat > 05-confirmacao-pedido/es.md << 'EOF'
✅ **¡PEDIDO CONFIRMADO!**

Hola [Nombre],

¡Tu pedido #[Número de Pedido] ha sido confirmado con éxito!

📦 **Detalles del pedido:**
• Producto: [Nombre del Producto]
• Cantidade: [X]
• Valor total: €[Valor]
• Forma de pago: [Método]
• Previsión de entrega: [Fecha]

🚚 **Seguimiento:**
• Código: [Código de Seguimiento]
• Enlace: [Enlace de Seguimiento]
• Transportista: [Nombre]

📞 **Soporte:**
¿Dudas sobre tu pedido? ¡Responde este mensaje!

¡Gracias por comprar con nosotros! 🎉

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 5 criado: Confirmação Pedido"

echo "📁 Criados 5 templates com 3 idiomas cada"
echo "Execute novamente para criar os templates 6-10 ou edite manualmente"
echo "Arquivo completo disponível em: whatsapp-templates-complete.md"