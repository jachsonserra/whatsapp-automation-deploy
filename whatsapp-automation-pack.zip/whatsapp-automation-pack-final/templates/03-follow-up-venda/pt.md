Olá [Nome]! 

Vi que você demonstrou interesse em nosso [Produto/Serviço]. 

Lembrei de você porque:
🎯 [Benefício 1 específico para o cliente]
🎯 [Benefício 2 que resolve dor mencionada]

**Oferta especial válida até [Data]:**
Preço normal: €[Valor]
Para você: €[Valor com desconto] (economia de [X]%)

👉 [Link para compra ou mais informações]

Perguntas? Estou aqui para ajudar!

Atenciosamente,
[Nome do Vendedor]
[Nome da Empresa]
