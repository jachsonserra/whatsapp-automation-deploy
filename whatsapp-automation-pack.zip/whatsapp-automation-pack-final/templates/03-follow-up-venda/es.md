¡Hola [Nombre]!

Vi que mostraste interés en nuestro [Producto/Servicio].

Me acordé de ti porque:
🎯 [Beneficio 1 específico para el cliente]
🎯 [Beneficio 2 que resuelve dolor mencionado]

**Oferta especial válida hasta [Fecha]:**
Precio normal: €[Valor]
Para ti: €[Valor con descuento] (ahorra [X]%)

👉 [Enlace para comprar o más información]

¿Preguntas? ¡Estoy aquí para ayudar!

Atentamente,
[Nombre del Vendedor]
[Nombre de la Empresa]
