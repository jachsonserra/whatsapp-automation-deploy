Hello [Name]!

I noticed you showed interest in our [Product/Service].

I thought of you because:
🎯 [Specific benefit 1 for the customer]
🎯 [Benefit 2 that solves mentioned pain point]

**Special offer valid until [Date]:**
Regular price: €[Amount]
For you: €[Discounted amount] (save [X]%)

👉 [Link to purchase or more information]

Questions? I'm here to help!

Best regards,
[Salesperson Name]
[Company Name]
