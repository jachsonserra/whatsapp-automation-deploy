🎉 **¡PROMOCIÓN ESPECIAL!** 🎉

¡Hola [Nombre]!

Tenemos una oferta exclusiva para ti:

**[Nombre de la Promoción]**
• [Beneficio 1]
• [Beneficio 2]
• [Beneficio 3]

💰 **Precio promocional:** €[Valor]
(Precio normal: €[Valor] - ahorra [X]%)

⏰ **Válido hasta:** [Fecha]
👥 **Solo para:** [Segmento de clientes]

👉 [Enlace para aprovechar]

¿Preguntas? ¡Estoy aquí! 😊

*Para no recibir promociones, responde "pausar".*

Atentamente,
Equipo [Nombre de la Empresa]
