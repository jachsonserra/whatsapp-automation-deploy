🎉 **SPECIAL PROMOTION!** 🎉

Hello [Name]!

We have an exclusive offer for you:

**[Promotion Name]**
• [Benefit 1]
• [Benefit 2]
• [Benefit 3]

💰 **Promotional price:** €[Amount]
(Regular price: €[Amount] - save [X]%)

⏰ **Valid until:** [Date]
👥 **Only for:** [Customer segment]

👉 [Link to take advantage]

Questions? I'm here! 😊

*To stop receiving promotions, reply "stop".*

Best regards,
[Company Name] Team
