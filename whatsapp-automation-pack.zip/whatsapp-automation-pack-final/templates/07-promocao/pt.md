🎉 **PROMOÇÃO ESPECIAL!** 🎉

Olá [Nome]!

Temos uma oferta exclusiva para você:

**[Nome da Promoção]**
• [Benefício 1]
• [Benefício 2]
• [Benefício 3]

💰 **Preço promocional:** €[Valor] 
(Valor normal: €[Valor] - economia de [X]%)

⏰ **Válido até:** [Data]
👥 **Apenas para clientes:** [Segmento]

👉 [Link para aproveitar]

Perguntas? Estou aqui! 😊

*Para não receber promoções, responda "pausar".*

Atenciosamente,
Equipe [Nome da Empresa]
