👋 Hello [Name], how are you?

I noticed it's been a while since your last interaction with us.

I'd like to know if:
✅ Everything is okay with your [Previous Product/Service]
✅ You have any questions or need help
✅ You'd like to know about our news

**Current offers that might interest you:**
• [Relevant offer 1]
• [Personalized offer 2]

👉 [Link to see news]

I'm at your disposal! 😊

*To stop receiving messages, reply "stop".*

Best regards,
[Company Name] Team
