👋 ¡Hola [Nombre], ¿cómo estás?

Noté que ha pasado un tiempo desde tu última interacción con nosotros.

Me gustaría saber si:
✅ Todo está bien con tu [Producto/Servicio anterior]
✅ Tienes alguna duda o necesitas ayuda
✅ Te gustaría conocer nuestras novedades

**Ofertas actuales que pueden interesarte:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Enlace para ver novedades]

¡Quedo a tu disposición! 😊

*Para no recibir más mensajes, responde "cancelar".*

Atentamente,
Equipo [Nombre de la Empresa]
