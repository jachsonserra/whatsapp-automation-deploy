👋 Olá [Nome], tudo bem?

Percebi que faz um tempo desde sua última interação conosco.

Gostaria de saber se:
✅ Está tudo certo com seu [Produto/Serviço anterior]
✅ Tem alguma dúvida ou precisa de ajuda
✅ Gostaria de conhecer nossas novidades

**Ofertas atuais que podem te interessar:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Link para ver novidades]

Fico à disposição! 😊

*Para não receber mais mensagens, responda "cancelar".*

Atenciosamente,
Equipe [Nome da Empresa]
