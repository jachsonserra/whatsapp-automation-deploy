#!/bin/bash

# Script para criar arquivos individuais (parte 2 - templates 6-10)

echo "Criando templates 6-10..."

# Template 6: Pesquisa Satisfação
cat > 06-pesquisa-satisfacao/pt.md << 'EOF'
Olá [Nome]!

Esperamos que tenha tido uma boa experiência com seu [Produto/Serviço Pedido].

Poderia nos ajudar com **1 minuto** do seu tempo?

Por favor, avalie de 1 a 5 estrelas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muito insatisfeito
2️⃣ ⭐️⭐️ - Insatisfeito  
3️⃣ ⭐️⭐️⭐️ - Neutro
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfeito
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muito satisfeito

**Comentário opcional:**
[Espaço para feedback]

Sua opinião nos ajuda a melhorar! 😊

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 06-pesquisa-satisfacao/en.md << 'EOF'
Hello [Name]!

We hope you had a good experience with your [Ordered Product/Service].

Could you help us with **1 minute** of your time?

Please rate from 1 to 5 stars:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Very dissatisfied
2️⃣ ⭐️⭐️ - Dissatisfied
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfied
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Very satisfied

**Optional comment:**
[Space for feedback]

Your opinion helps us improve! 😊

Best regards,
[Company Name] Team
EOF

cat > 06-pesquisa-satisfacao/es.md << 'EOF'
¡Hola [Nombre]!

Esperamos que hayas tenido una buena experiencia con tu [Producto/Servicio Pedido].

¿Podrías ayudarnos con **1 minuto** de tu tiempo?

Por favor, califica de 1 a 5 estrellas:
⭐️⭐️⭐️⭐️⭐️

1️⃣ ⭐️ - Muy insatisfecho
2️⃣ ⭐️⭐️ - Insatisfecho
3️⃣ ⭐️⭐️⭐️ - Neutral
4️⃣ ⭐️⭐️⭐️⭐️ - Satisfecho
5️⃣ ⭐️⭐️⭐️⭐️⭐️ - Muy satisfecho

**Comentario opcional:**
[Espacio para feedback]

¡Tu opinión nos ayuda a mejorar! 😊

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 6 criado: Pesquisa Satisfação"

# Template 7: Promoção
cat > 07-promocao/pt.md << 'EOF'
🎉 **PROMOÇÃO ESPECIAL!** 🎉

Olá [Nome]!

Temos uma oferta exclusiva para você:

**[Nome da Promoção]**
• [Benefício 1]
• [Benefício 2]
• [Benefício 3]

💰 **Preço promocional:** €[Valor] 
(Valor normal: €[Valor] - economia de [X]%)

⏰ **Válido até:** [Data]
👥 **Apenas para clientes:** [Segmento]

👉 [Link para aproveitar]

Perguntas? Estou aqui! 😊

*Para não receber promoções, responda "pausar".*

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 07-promocao/en.md << 'EOF'
🎉 **SPECIAL PROMOTION!** 🎉

Hello [Name]!

We have an exclusive offer for you:

**[Promotion Name]**
• [Benefit 1]
• [Benefit 2]
• [Benefit 3]

💰 **Promotional price:** €[Amount]
(Regular price: €[Amount] - save [X]%)

⏰ **Valid until:** [Date]
👥 **Only for:** [Customer segment]

👉 [Link to take advantage]

Questions? I'm here! 😊

*To stop receiving promotions, reply "stop".*

Best regards,
[Company Name] Team
EOF

cat > 07-promocao/es.md << 'EOF'
🎉 **¡PROMOCIÓN ESPECIAL!** 🎉

¡Hola [Nombre]!

Tenemos una oferta exclusiva para ti:

**[Nombre de la Promoción]**
• [Beneficio 1]
• [Beneficio 2]
• [Beneficio 3]

💰 **Precio promocional:** €[Valor]
(Precio normal: €[Valor] - ahorra [X]%)

⏰ **Válido hasta:** [Fecha]
👥 **Solo para:** [Segmento de clientes]

👉 [Enlace para aprovechar]

¿Preguntas? ¡Estoy aquí! 😊

*Para no recibir promociones, responde "pausar".*

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 7 criado: Promoção"

# Template 8: Reengajamento
cat > 08-reengajamento/pt.md << 'EOF'
👋 Olá [Nome], tudo bem?

Percebi que faz um tempo desde sua última interação conosco.

Gostaria de saber se:
✅ Está tudo certo com seu [Produto/Serviço anterior]
✅ Tem alguma dúvida ou precisa de ajuda
✅ Gostaria de conhecer nossas novidades

**Ofertas atuais que podem te interessar:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Link para ver novidades]

Fico à disposição! 😊

*Para não receber mais mensagens, responda "cancelar".*

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 08-reengajamento/en.md << 'EOF'
👋 Hello [Name], how are you?

I noticed it's been a while since your last interaction with us.

I'd like to know if:
✅ Everything is okay with your [Previous Product/Service]
✅ You have any questions or need help
✅ You'd like to know about our news

**Current offers that might interest you:**
• [Relevant offer 1]
• [Personalized offer 2]

👉 [Link to see news]

I'm at your disposal! 😊

*To stop receiving messages, reply "stop".*

Best regards,
[Company Name] Team
EOF

cat > 08-reengajamento/es.md << 'EOF'
👋 ¡Hola [Nombre], ¿cómo estás?

Noté que ha pasado un tiempo desde tu última interacción con nosotros.

Me gustaría saber si:
✅ Todo está bien con tu [Producto/Servicio anterior]
✅ Tienes alguna duda o necesitas ayuda
✅ Te gustaría conocer nuestras novedades

**Ofertas actuales que pueden interesarte:**
• [Oferta 1 relevante]
• [Oferta 2 personalizada]

👉 [Enlace para ver novedades]

¡Quedo a tu disposición! 😊

*Para no recibir más mensajes, responde "cancelar".*

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 8 criado: Reengajamento"

# Template 9: Suporte Técnico
cat > 09-suporte-tecnico/pt.md << 'EOF'
🔧 **SUPORTE TÉCNICO**

Olá [Nome],

Entendi que está com dificuldade em: [Descrever problema brevemente].

**Solução rápida tentar agora:**
1. [Passo 1 simples]
2. [Passo 2 simples]
3. [Passo 3 simples]

Se não resolver, precisarei de:
📱 **Informações do dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versão do app: [ ]

📋 **Detalhes do problema:**
• Quando começou: [ ]
• O que tentou: [ ]
• Screenshot: [Pode enviar]

⏰ **Tempo de resposta:**
Resolvemos 80% dos casos em até 2h.

Atenciosamente,
Equipe de Suporte [Nome da Empresa]
EOF

cat > 09-suporte-tecnico/en.md << 'EOF'
🔧 **TECHNICAL SUPPORT**

Hello [Name],

I understand you're having difficulty with: [Briefly describe problem].

**Quick solution to try now:**
1. [Simple step 1]
2. [Simple step 2]
3. [Simple step 3]

If it doesn't work, I'll need:
📱 **Device information:**
• Model: [ ]
• System: [ ]
• App version: [ ]

📋 **Problem details:**
• When it started: [ ]
• What you tried: [ ]
• Screenshot: [Can send]

⏰ **Response time:**
We resolve 80% of cases within 2 hours.

Best regards,
[Company Name] Support Team
EOF

cat > 09-suporte-tecnico/es.md << 'EOF'
🔧 **SOPORTE TÉCNICO**

¡Hola [Nombre],

Entendí que tienes dificultad con: [Describir problema brevemente].

**Solución rápida para intentar ahora:**
1. [Paso 1 simple]
2. [Paso 2 simple]
3. [Paso 3 simple]

Si no resuelve, necesitaré:
📱 **Información del dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versión de la app: [ ]

📋 **Detalles del problema:**
• Cuándo comenzó: [ ]
• Qué intentaste: [ ]
• Captura de pantalla: [Puedes enviar]

⏰ **Tiempo de respuesta:**
Resolvemos 80% de los casos en hasta 2 horas.

Atentamente,
Equipo de Soporte [Nombre de la Empresa]
EOF

echo "✅ Template 9 criado: Suporte Técnico"

# Template 10: Encerramento
cat > 10-encerramento/pt.md << 'EOF'
✅ **ATENDIMENTO CONCLUÍDO**

Olá [Nome],

Confirmo que seu atendimento foi finalizado.

📋 **Resumo:**
• Problema: [Descrição breve]
• Solução aplicada: [Descrição breve]
• Próximos passos: [Se aplicável]

⭐️ **Avaliação (opcional):**
Como classifica nosso atendimento?
1-5 estrelas: ⭐️⭐️⭐️⭐️⭐️

📁 **Registro:**
Este atendimento foi registrado sob protocolo #[Número].

📞 **Próximo contato:**
Se precisar novamente, basta responder esta conversa!

Obrigado por confiar em nós! 🙏

Atenciosamente,
Equipe [Nome da Empresa]
EOF

cat > 10-encerramento/en.md << 'EOF'
✅ **SERVICE COMPLETED**

Hello [Name],

I confirm that your service has been completed.

📋 **Summary:**
• Problem: [Brief description]
• Solution applied: [Brief description]
• Next steps: [If applicable]

⭐️ **Rating (optional):**
How do you rate our service?
1-5 stars: ⭐️⭐️⭐️⭐️⭐️

📁 **Record:**
This service was recorded under protocol #[Number].

📞 **Next contact:**
If you need again, just reply to this conversation!

Thank you for trusting us! 🙏

Best regards,
[Company Name] Team
EOF

cat > 10-encerramento/es.md << 'EOF'
✅ **ATENCIÓN FINALIZADA**

¡Hola [Nombre],

Confirmo que tu atención ha sido finalizada.

📋 **Resumen:**
• Problema: [Descripción breve]
• Solución aplicada: [Descripción breve]
• Próximos pasos: [Si aplica]

⭐️ **Evaluación (opcional):**
¿Cómo calificas nuestra atención?
1-5 estrellas: ⭐️⭐️⭐️⭐️⭐️

📁 **Registro:**
Esta atención fue registrada bajo protocolo #[Número].

📞 **Próximo contacto:**
¡Si necesitas nuevamente, solo responde esta conversación!

¡Gracias por confiar en nosotros! 🙏

Atentamente,
Equipo [Nombre de la Empresa]
EOF

echo "✅ Template 10 criado: Encerramento"

echo "🎉 Todos os 10 templates criados com sucesso!"
echo "📊 Total: 10 templates × 3 idiomas = 30 arquivos"
echo "📁 Estrutura completa em: /Users/jachsonserra/.openclaw/workspace/whatsapp-automation-pack-final/templates/"