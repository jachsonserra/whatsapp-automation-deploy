🔧 **SOPORTE TÉCNICO**

¡Hola [Nombre],

Entendí que tienes dificultad con: [Describir problema brevemente].

**Solución rápida para intentar ahora:**
1. [Paso 1 simple]
2. [Paso 2 simple]
3. [Paso 3 simple]

Si no resuelve, necesitaré:
📱 **Información del dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versión de la app: [ ]

📋 **Detalles del problema:**
• Cuándo comenzó: [ ]
• Qué intentaste: [ ]
• Captura de pantalla: [Puedes enviar]

⏰ **Tiempo de respuesta:**
Resolvemos 80% de los casos en hasta 2 horas.

Atentamente,
Equipo de Soporte [Nombre de la Empresa]
