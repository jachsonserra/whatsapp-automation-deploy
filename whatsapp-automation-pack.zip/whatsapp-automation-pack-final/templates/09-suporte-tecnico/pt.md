🔧 **SUPORTE TÉCNICO**

Olá [Nome],

Entendi que está com dificuldade em: [Descrever problema brevemente].

**Solução rápida tentar agora:**
1. [Passo 1 simples]
2. [Passo 2 simples]
3. [Passo 3 simples]

Se não resolver, precisarei de:
📱 **Informações do dispositivo:**
• Modelo: [ ]
• Sistema: [ ]
• Versão do app: [ ]

📋 **Detalhes do problema:**
• Quando começou: [ ]
• O que tentou: [ ]
• Screenshot: [Pode enviar]

⏰ **Tempo de resposta:**
Resolvemos 80% dos casos em até 2h.

Atenciosamente,
Equipe de Suporte [Nome da Empresa]
