🔧 **TECHNICAL SUPPORT**

Hello [Name],

I understand you're having difficulty with: [Briefly describe problem].

**Quick solution to try now:**
1. [Simple step 1]
2. [Simple step 2]
3. [Simple step 3]

If it doesn't work, I'll need:
📱 **Device information:**
• Model: [ ]
• System: [ ]
• App version: [ ]

📋 **Problem details:**
• When it started: [ ]
• What you tried: [ ]
• Screenshot: [Can send]

⏰ **Response time:**
We resolve 80% of cases within 2 hours.

Best regards,
[Company Name] Support Team
