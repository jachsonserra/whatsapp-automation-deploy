# Guia GDPR para Automação WhatsApp Business

## 1. O que é o GDPR?

O **Regulamento Geral sobre a Proteção de Dados (GDPR)** é a legislação europeia que estabelece regras para a proteção de dados pessoais de cidadãos da União Europeia. Aplicável desde 25 de maio de 2018, o GDPR tem como objetivo dar aos indivíduos maior controle sobre seus dados pessoais e unificar as regulamentações de privacidade em toda a UE.

**Princípios fundamentais do GDPR:**
- **Legalidade, transparência e justiça:** Os dados devem ser processados de forma legal, transparente e justa.
- **Limitação da finalidade:** Os dados devem ser coletados para fins específicos, explícitos e legítimos.
- **Minimização de dados:** Apenas os dados necessários para a finalidade devem ser coletados.
- **Exatidão:** Os dados devem ser precisos e atualizados.
- **Limitação de armazenamento:** Os dados não devem ser mantidos por mais tempo do que o necessário.
- **Integridade e confidencialidade:** Os dados devem ser processados de forma segura.
- **Responsabilização:** O controlador dos dados é responsável por cumprir esses princípios.

**Aplicação ao WhatsApp Business:**
Mesmo sendo uma empresa fora da UE, se você lida com dados de cidadãos europeus, o GDPR se aplica. Isso inclui clientes da UE que você contata via WhatsApp.

---

## 2. Regras para Mensagens Comerciais no WhatsApp

O WhatsApp Business tem suas próprias políticas, que devem ser alinhadas com o GDPR. As principais regras incluem:

**Consentimento prévio:**
- Você só pode enviar mensagens comerciais para usuários que **consentiram explicitamente** em recebê-las.
- O consentimento deve ser **livre, específico, informado e inequívoco**.
- Não basta ter o número de telefone; você precisa de permissão para usá-lo com fins de marketing.

**Identificação clara:**
- Todas as mensagens devem identificar claramente quem está enviando (sua empresa).
- O conteúdo não pode ser enganoso ou fraudulento.

**Opt-out fácil:**
- Você deve fornecer uma maneira simples para o destinatário cancelar a inscrição (ex: "Responda SAIR para cancelar").
- Uma vez cancelado, você não pode mais enviar mensagens comerciais para esse número.

**Limitação de horário:**
- Evite enviar mensagens em horários inadequados (ex: madrugada).
- Respeite os fusos horários dos destinatários.

**Conteúdo apropriado:**
- Não envie spam, conteúdo ilegal, ofensivo ou prejudicial.
- Siga as [Políticas de Negócios do WhatsApp](https://www.whatsapp.com/legal/business-policy/).

---

## 3. Consentimento Explícito – Como Obter e Documentar

O consentimento é a base legal mais importante para marketing via WhatsApp. Veja como obtê-lo corretamente:

### Formas válidas de consentimento:
1. **Formulário online:** Checkbox não pré-marcada com texto claro:
   *"Aceito receber mensagens de marketing via WhatsApp sobre [produto/serviço] da [Empresa]. Posso cancelar a qualquer momento."*
2. **SMS/WhatsApp inicial:** O cliente envia uma mensagem primeiro demonstrando interesse.
3. **Contato presencial/telefônico:** Após explicação, o cliente concorda verbalmente ou por escrito.
4. **Cupom ou promoção:** Ao participar, o cliente opta por receber comunicações.

### O que NÃO é consentimento válido:
- Compra de listas de contatos
- Números obtidos de redes sociais sem permissão
- Presunção de interesse ("eles me deram o cartão, então posso")
- Checkbox pré-marcada ou termos ocultos

### Documentação do consentimento:
- **Guarde registros** de quando, como e que consentimento foi dado.
- **Mantenha um log** incluindo:
  - Número de telefone
  - Data e hora do consentimento
  - Método de obtenção (formulário, SMS, etc.)
  - Texto exato apresentado ao usuário
  - Finalidade específica do uso
- **Atualize os registros** quando o consentimento for revogado.

---

## 4. Direito ao Esquecimento (Direito de Exclusão)

O GDPR concede aos indivíduos o **"direito ao esquecimento"** (Artigo 17), que permite solicitar a exclusão de seus dados pessoais.

### Quando se aplica:
- Os dados não são mais necessários para a finalidade original
- O indivíduo retira o consentimento
- Os dados foram processados ilegalmente
- Há obrigação legal para apagar os dados

### Como implementar no WhatsApp Automation:
1. **Processo de exclusão:**
   - Configure um fluxo para quando alguém pedir "apagar meus dados"
   - Remova o número de todas as suas listas de contatos
   - Apague registros de conversas (após período de retenção legal)
   - Confirme a exclusão ao solicitante

2. **Retenção de dados:**
   - Defina um período máximo de retenção (ex: 2 anos após último contato)
   - Crie um calendário para exclusão automática de dados antigos
   - Mantenha apenas dados necessários para cumprir obrigações legais

3. **Exceções:**
   - Você pode reter dados se necessário para:
     - Exercício do direito à liberdade de expressão
     - Cumprimento de obrigação legal
     - Interesses públicos de saúde
     - Fins de arquivo de interesse público, pesquisa científica ou histórica
     - Defesa de reivindicações legais

---

## 5. Templates de Mensagem Aprovados (GDPR-Compliant)

Use estes modelos como base para suas comunicações:

### Template 1 – Solicitação de Consentimento
```
Olá [Nome], sou [Seu Nome] da [Empresa]. Gostaríamos de enviar ofertas exclusivas e novidades via WhatsApp. 

Para confirmar seu interesse e aceitar, responda SIM.

🔒 Seus dados são protegidos pela LGPD/GDPR. Pode cancelar a qualquer momento respondendo SAIR.
```

### Template 2 – Confirmação de Consentimento
```
✅ Obrigado! Você agora receberá nossas comunicações.

Frequência: 1-2 mensagens por semana
Conteúdo: Ofertas, dicas e novidades sobre [produto/serviço]

Para cancelar: Responda SAIR a qualquer momento.
Para ajuda: Responda AJUDA
```

### Template 3 – Mensagem com Opt-Out Claro
```
[Nome], temos uma oferta especial para você! 

[Detalhes da oferta]

⚠️ Esta é uma mensagem comercial. Responda SAIR para não receber mais ofertas.
```

### Template 4 – Pesquisa de Satisfação (Pós-Consentimento)
```
Olá [Nome], esperamos que tenha gostado do [produto/serviço]. 

Poderia nos dar uma nota de 1 a 5? (1=ruim, 5=excelente)

Sua opinião nos ajuda a melhorar!

🔒 Dados usados apenas para análise interna. Responda SAIR para cancelar comunicações.
```

### Template 5 – Atualização de Política de Privacidade
```
Importante: Atualizamos nossa Política de Privacidade para maior transparência.

Principais mudanças:
- Como protegemos seus dados
- Seus direitos atualizados
- Períodos de retenção

Leia a versão completa: [link]

Continuar recebendo mensagens? Responda SIM. Cancelar? Responda SAIR.
```

---

## 6. Checklist de Compliance GDPR

Use esta lista para garantir conformidade:

### ✅ Antes de Iniciar
- [ ] Mapeei todos os dados pessoais que coletei/processo
- [ ] Defini a base legal para cada tipo de processamento
- [ ] Criei uma Política de Privacidade clara e acessível
- [ ] Estabeleci contratos com fornecedores (processadores de dados)
- [ ] Designei um responsável pela proteção de dados (se necessário)

### ✅ Consentimento
- [ ] Obtenho consentimento explícito antes de enviar mensagens comerciais
- [ ] Documento como, quando e que consentimento foi dado
- [ ] Ofereço opt-out fácil em todas as mensagens
- [ ] Respeito imediatamente as solicitações de cancelamento

### ✅ Transparência
- [ ] Informo identidade da empresa em todas as comunicações
- [ ] Explico a finalidade do uso dos dados
- [ ] Forneço informações de contato para dúvidas sobre privacidade
- [ ] Mantenho registros de processamento de dados

### ✅ Direitos dos Titulares
- [ ] Tenho processo para atender solicitações de acesso a dados
- [ ] Posso corrigir dados incorretos quando solicitado
- [ ] Apago dados quando o direito ao esquecimento é invocado
- [ ] Permito a portabilidade de dados (fornecer dados em formato estruturado)

### ✅ Segurança
- [ ] Implementei medidas técnicas para proteger dados (criptografia, acesso restrito)
- [ ] Treino minha equipe sobre proteção de dados
- [ ] Tenho plano para notificar violações de dados dentro de 72 horas
- [ ] Realizo avaliações regulares de riscos à privacidade

### ✅ WhatsApp Específico
- [ ] Sigo as Políticas de Negócios do WhatsApp
- [ ] Não uso o WhatsApp para spam ou mensagens não solicitadas
- [ ] Respeito os limites de mensagens da plataforma
- [ ] Mantenho registros de consentimento específicos para WhatsApp

---

## 7. Penalidades por Não Conformidade

As multas do GDPR são significativas e podem ser aplicadas em dois níveis:

### Nível 1 – Infrações Menos Graves
- Violações de requisitos de documentação
- Falha em notificar violação de dados
- Falha em realizar avaliação de impacto
- **Multa:** até €10 milhões ou 2% do faturamento global anual (o que for maior)

### Nível 2 – Infrações Graves
- Violação dos princípios básicos de processamento
- Infração dos direitos dos titulares de dados
- Transferência ilegal de dados para países terceiros
- **Multa:** até €20 milhões ou 4% do faturamento global anual (o que for maior)

### Casos Reais de Multas:
- **WhatsApp Ireland Ltd:** €225 milhões por falta de transparência (2021)
- **Google LLC:** €50 milhões por falta de consentimento válido (2019)
- **H&M:** €35 milhões por monitoramento excessivo de funcionários (2020)

### Consequências Adicionais:
- **Danos à reputação:** Perda de confiança dos clientes
- **Ações judiciais:** Indivíduos podem processar por danos
- **Ordens corretivas:** Autoridades podem ordenar parada do processamento
- **Bloqueio de dados:** Proibição de processar dados temporária ou permanente

---

## 8. Recursos e Próximos Passos

### Ferramentas Úteis:
- **Gerador de Política de Privacidade:** [Privacy Policy Generator](https://www.privacypolicies.com/)
- **Checklist GDPR:** [GDPR Checklist](https://gdprchecklist.io/)
- **Modelos de Consentimento:** [ICO Consent Guidance](https://ico.org.uk/)
- **Cursos Online:** Coursera, Udemy (GDPR para empresas)

### Próximos Passos Imediatos:
1. **Revise seus processos atuais** – Identifique onde coleta dados de clientes
2. **Atualize sua Política de Privacidade** – Torne-a clara e acessível
3. **Implemente sistema de consentimento** – Para novos contatos
4. **Documente tudo** – Crie registros de processamento de dados
5. **Treine sua equipe** – Todos devem entender os princípios do GDPR

### Contatos Úteis:
- **Autoridade Nacional de Proteção de Dados (Portugal):** [CNPD](https://www.cnpd.pt/)
- **Comissão Nacional de Proteção de Dados (Brasil):** [ANPD](https://www.gov.br/anpd/)
- **Autoridade Europeia de Proteção de Dados:** [EDPB](https://edpb.europa.eu/)

### Mantenha-se Atualizado:
- Assine newsletters sobre privacidade de dados
- Participe de webinars sobre GDPR
- Consulte um advogado especializado para situações complexas

---

## Aviso Legal
Este guia fornece informações gerais sobre o GDPR e não constitui aconselhamento jurídico. Para orientação específica sobre sua situação, consulte um profissional qualificado em proteção de dados.

**Última atualização:** 11 de abril de 2026

---
*Parte do WhatsApp Automation Pack – Sistema completo para automação WhatsApp Business em conformidade com leis de proteção de dados.*