#!/usr/bin/env python3
"""
WhatsApp Auto-Reply with GDPR Compliance
Simple script for automated responses with privacy considerations.
"""
import json
import time
import re
from datetime import datetime

# GDPR-compliant response templates
RESPONSE_TEMPLATES = {
    "welcome": {
        "en": "Hello! Thanks for your message. We'll reply as soon as possible during business hours (9AM-6PM CET). For urgent matters, please call us.",
        "pt": "Olá! Obrigado pela sua mensagem. Responderemos o mais breve possível durante o horário comercial (9h-18h CET). Para assuntos urgentes, por favor ligue.",
        "es": "¡Hola! Gracias por tu mensaje. Responderemos lo antes posible durante el horario comercial (9AM-6PM CET). Para asuntos urgentes, por favor llámanos."
    },
    "faq": {
        "en": "For frequently asked questions, visit our FAQ page: [YOUR_FAQ_LINK]",
        "pt": "Para perguntas frequentes, visite nossa página de FAQ: [SEU_LINK_FAQ]",
        "es": "Para preguntas frecuentes, visita nuestra página de FAQ: [TU_ENLACE_FAQ]"
    },
    "business_hours": {
        "en": "You've reached us outside business hours. We'll reply on the next business day.",
        "pt": "Você nos contactou fora do horário comercial. Responderemos no próximo dia útil.",
        "es": "Nos has contactado fuera del horario comercial. Responderemos el próximo día laboral."
    }
}

# Keywords for auto-detection
KEYWORDS = {
    "hello": ["hello", "hi", "hey", "olá", "oi", "hola"],
    "price": ["price", "cost", "how much", "preço", "custo", "precio", "costo"],
    "hours": ["hours", "open", "horário", "horario", "schedule"],
    "urgent": ["urgent", "emergency", "urgente", "emergencia"]
}

def load_config():
    """Load configuration from JSON file."""
    try:
        with open("whatsapp-config.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        # Default configuration
        return {
            "business_hours": {"start": 9, "end": 18},
            "timezone": "CET",
            "company_name": "Your Company",
            "language": "en",
            "gdpr_compliant": True,
            "require_consent": True
        }

def is_business_hours(config):
    """Check if current time is within business hours."""
    now = datetime.now()
    hour = now.hour
    return config["business_hours"]["start"] <= hour < config["business_hours"]["end"]

def detect_intent(message):
    """Detect user intent based on keywords."""
    message_lower = message.lower()
    for intent, keywords in KEYWORDS.items():
        for keyword in keywords:
            if keyword in message_lower:
                return intent
    return "general"

def get_gdpr_consent_message(lang="en"):
    """Return GDPR consent request message."""
    messages = {
        "en": "To continue, we need your consent to process your data according to GDPR. Reply 'YES' to consent to our privacy policy: [YOUR_PRIVACY_LINK]",
        "pt": "Para continuar, precisamos do seu consentimento para processar seus dados conforme o GDPR. Responda 'SIM' para consentir com nossa política de privacidade: [SEU_LINK_PRIVACIDADE]",
        "es": "Para continuar, necesitamos tu consentimiento para procesar tus datos según el GDPR. Responde 'SÍ' para consentir nuestra política de privacidad: [TU_ENLACE_PRIVACIDAD]"
    }
    return messages.get(lang, messages["en"])

def send_response(phone_number, response_text):
    """Simulate sending response (integrate with your WhatsApp API)."""
    print(f"[{datetime.now().isoformat()}] To {phone_number}: {response_text}")
    # In production, integrate with:
    # - WhatsApp Business API
    # - Twilio WhatsApp
    # - Python WhatsApp library
    
    # Log for GDPR compliance
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "to": phone_number,
        "message": response_text,
        "gdpr_notice_sent": "gdpr" in response_text.lower()
    }
    
    with open("whatsapp-gdpr-log.json", "a") as f:
        f.write(json.dumps(log_entry) + "\n")
    
    return True

def process_message(phone_number, message, config):
    """Process incoming message and generate response."""
    lang = config.get("language", "en")
    
    # Check GDPR consent if required
    if config.get("require_consent", True) and not check_consent(phone_number):
        consent_msg = get_gdpr_consent_message(lang)
        send_response(phone_number, consent_msg)
        return
    
    # Check business hours
    if not is_business_hours(config):
        response = RESPONSE_TEMPLATES["business_hours"].get(lang, RESPONSE_TEMPLATES["business_hours"]["en"])
        send_response(phone_number, response)
        return
    
    # Detect intent
    intent = detect_intent(message)
    
    if intent == "hello":
        response = RESPONSE_TEMPLATES["welcome"].get(lang, RESPONSE_TEMPLATES["welcome"]["en"])
    elif intent == "price":
        response = RESPONSE_TEMPLATES["faq"].get(lang, RESPONSE_TEMPLATES["faq"]["en"])
    else:
        response = RESPONSE_TEMPLATES["welcome"].get(lang, RESPONSE_TEMPLATES["welcome"]["en"])
    
    send_response(phone_number, response)

def check_consent(phone_number):
    """Check if user has given GDPR consent."""
    try:
        with open("gdpr-consents.json", "r") as f:
            consents = json.load(f)
            return phone_number in consents and consents[phone_number] == "yes"
    except FileNotFoundError:
        return False

def main():
    """Main function."""
    print("WhatsApp Auto-Reply GDPR Bot")
    print("=" * 40)
    
    config = load_config()
    print(f"Configuration loaded: {config['company_name']}")
    print(f"GDPR Compliance: {config['gdpr_compliant']}")
    print(f"Business hours: {config['business_hours']['start']}:00-{config['business_hours']['end']}:00 {config['timezone']}")
    
    # Example usage
    print("\nExample message processing:")
    process_message("+1234567890", "Hello, what's your price?", config)
    
    print("\nTo use this script:")
    print("1. Edit 'whatsapp-config.json' with your settings")
    print("2. Integrate with your WhatsApp API")
    print("3. Run as service: python auto-reply-gdpr.py")
    print("\nGDPR logs saved to: whatsapp-gdpr-log.json")

if __name__ == "__main__":
    main()