#!/usr/bin/env python3
"""
WhatsApp Basic Monitor - Monitors WhatsApp groups for new messages and sends notifications.
Designed for Jachson Serra's workflow with GDPR compliance considerations.
"""
import os
import sys
import json
import subprocess
import time
from datetime import datetime, timedelta
import re
from pathlib import Path

# ============================================================================
# CONFIGURATION - edit these according to your environment
# ============================================================================
CHECK_INTERVAL = 30  # seconds between checks

# Work groups to monitor (JID: Name)
WORK_GROUPS = {
    "120363426271832695@g.us": "AÇAÍ AMAZONIA",
    "120363418660391748@g.us": "Producción Amazonia açai", 
    "120363420953778385@g.us": "Equipo logístico",
    "120363423435275511@g.us": "AMAZONIA RIVAS"
}

# JIDs to completely ignore (status updates, newsletters, etc.)
IGNORE_JIDS = [
    "status@broadcast",
    "120363425781398704@newsletter",
]

# Telegram notification settings
TELEGRAM_ENABLED = True
TELEGRAM_TARGET = "8003061600"  # Jachson's Telegram ID

# Logging
LOG_FILE = "/tmp/whatsapp_monitor_basic.log"
STATE_FILE = "/tmp/whatsapp_monitor_state.json"

# ============================================================================
# GLOBAL STATE
# ============================================================================
processed_ids = set()

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def load_state():
    """Load previously processed message IDs from state file."""
    global processed_ids
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, 'r') as f:
                data = json.load(f)
                processed_ids = set(data.get("processed_ids", []))
                log(f"Loaded {len(processed_ids)} processed message IDs")
    except Exception as e:
        log(f"Error loading state: {e}")

def save_state():
    """Save processed message IDs to state file."""
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump({"processed_ids": list(processed_ids)}, f)
    except Exception as e:
        log(f"Error saving state: {e}")

def log(message):
    """Log message to file and stdout with timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def run_wacli(cmd):
    """Execute wacli command and return stdout."""
    try:
        result = subprocess.run(["wacli"] + cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            log(f"wacli error: {result.stderr[:200]}")
            return ""
        return result.stdout.strip()
    except Exception as e:
        log(f"wacli error: {e}")
        return ""

def get_recent_messages(minutes=5):
    """
    Fetch recent messages from WhatsApp.
    
    Args:
        minutes: Look back N minutes for messages
        
    Returns:
        List of message dictionaries
    """
    after_time = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d")
    cmd = ["messages", "search", ".", "--after", after_time, "--limit", "30", "--json"]
    output = run_wacli(cmd)
    if not output:
        log("No output from wacli")
        return []
    
    try:
        data = json.loads(output)
        if not data.get("success"):
            log(f"wacli error: {data.get('error')}")
            return []
        
        messages = data.get("data", {}).get("messages", [])
        # Filter only received messages (not sent by me)
        received = [m for m in messages if not m.get("FromMe", True)]
        # Filter ignored JIDs
        received = [m for m in received if m.get("ChatJID", "") not in IGNORE_JIDS]
        # Filter empty messages (media without text)
        received = [m for m in received if m.get("Text", "") or m.get("MediaType", "")]
        # Sort by timestamp (oldest first)
        received.sort(key=lambda x: x.get("Timestamp", ""))
        log(f"Found {len(received)} received messages after filtering")
        return received
    except json.JSONDecodeError as e:
        log(f"JSON decode error: {e}")
        log(f"Output: {output[:200]}")
        return []

def is_work_group(chat_jid):
    """Check if a chat JID belongs to a work group."""
    return chat_jid in WORK_GROUPS

def format_notification(message):
    """Format message for Telegram notification."""
    chat_jid = message.get("ChatJID", "")
    chat_name = message.get("ChatName", "")
    sender = message.get("SenderJID", "").split(":")[0] if ":" in message.get("SenderJID", "") else message.get("SenderJID", "")
    body = message.get("Text", "")
    media_type = message.get("MediaType", "")
    
    # Handle media-only messages
    if not body and media_type:
        body = f"[{media_type}]"
    
    if is_work_group(chat_jid):
        group_name = WORK_GROUPS.get(chat_jid, chat_name)
        return f"📱 WhatsApp Work Group: {group_name}\n👤 From: {sender}\n💬 Message: \"{body[:200]}\"\n\n📋 How should I respond?"
    else:
        return f"📱 WhatsApp Personal\n👤 From: {sender}\n💬 Message: \"{body[:200]}\"\n\n📋 Needs response?"

def send_telegram_notification(message):
    """Send notification to Telegram via OpenClaw."""
    if not TELEGRAM_ENABLED:
        log("Telegram notifications disabled")
        return False
    
    cmd = [
        "openclaw", "message", "send",
        "--channel", "telegram",
        "--target", TELEGRAM_TARGET,
        "--message", message
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            log("Telegram notification sent successfully")
            return True
        else:
            log(f"Telegram error: {result.stderr[:200]}")
            return False
    except Exception as e:
        log(f"Telegram exception: {e}")
        return False

def check_sync():
    """Check if wacli sync is running."""
    try:
        subprocess.run(["pgrep", "-f", "wacli sync"], capture_output=True)
        log("wacli sync is running")
        return True
    except:
        log("wacli sync is NOT running")
        return False

def start_sync_background():
    """Start wacli sync in background if not already running."""
    if not check_sync():
        log("Starting wacli sync in background...")
        subprocess.Popen(
            ["wacli", "sync", "--follow"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        time.sleep(2)  # Give it a moment to start
        if check_sync():
            log("wacli sync started successfully")
        else:
            log("Failed to start wacli sync")

# ============================================================================
# MAIN MONITORING LOOP
# ============================================================================

def main():
    """Main monitoring loop."""
    log("=" * 60)
    log("WhatsApp Basic Monitor - Started")
    log(f"Monitoring {len(WORK_GROUPS)} work groups")
    log(f"Check interval: {CHECK_INTERVAL} seconds")
    log("=" * 60)
    
    # Load previous state
    load_state()
    
    # Start sync in background if needed
    start_sync_background()
    
    try:
        while True:
            now = datetime.now()
            log(f"Checking for new messages...")
            
            # Fetch messages from last 10 minutes
            messages = get_recent_messages(minutes=10)
            new_count = 0
            notifications_sent = 0
            
            for msg in messages:
                msg_id = msg.get("MsgID")
                if not msg_id or msg_id in processed_ids:
                    continue
                
                processed_ids.add(msg_id)
                new_count += 1
                
                chat_jid = msg.get("ChatJID", "")
                chat_name = msg.get("ChatName", "")
                body = msg.get("Text", "")
                media_type = msg.get("MediaType", "")
                
                # Log the new message
                log_msg = f"New message: {chat_name[:20]} → "
                if body:
                    log_msg += f"{body[:60]}..."
                elif media_type:
                    log_msg += f"[{media_type}]"
                else:
                    log_msg += "[no text]"
                log(log_msg)
                
                # Always notify for work groups
                if is_work_group(chat_jid):
                    log("  → Work group, sending notification")
                    notification = format_notification(msg)
                    if send_telegram_notification(notification):
                        notifications_sent += 1
                else:
                    # Personal messages: notify if important
                    log("  → Personal message, evaluating importance")
                    if body and (
                        len(body) > 80 or 
                        '?' in body or 
                        any(word in body.lower() for word in ["urgente", "importante", "preciso", "pode", "ajuda"])
                    ):
                        notification = format_notification(msg)
                        if send_telegram_notification(notification):
                            notifications_sent += 1
            
            # Save state periodically
            if new_count > 0:
                save_state()
                log(f"Processed {new_count} new messages, sent {notifications_sent} notifications")
            else:
                log("No new messages")
            
            log(f"Waiting {CHECK_INTERVAL} seconds...")
            time.sleep(CHECK_INTERVAL)
            
    except KeyboardInterrupt:
        log("\n" + "=" * 60)
        log("Monitor stopped by user")
        save_state()
        log("State saved")
        log("=" * 60)
    except Exception as e:
        log(f"Unexpected error: {e}")
        import traceback
        log(traceback.format_exc())
        save_state()
        log("Emergency state saved")

# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    # Check if wacli is installed
    try:
        subprocess.run(["wacli", "--version"], capture_output=True, check=True)
    except FileNotFoundError:
        log("ERROR: wacli is not installed. Please install it first.")
        log("Install via: brew install steipete/tap/wacli")
        sys.exit(1)
    
    # Check if OpenClaw is available (for Telegram)
    if TELEGRAM_ENABLED:
        try:
            subprocess.run(["openclaw", "--version"], capture_output=True)
        except FileNotFoundError:
            log("WARNING: OpenClaw not found. Telegram notifications disabled.")
            TELEGRAM_ENABLED = False
    
    # Create log directory if needed
    log_dir = os.path.dirname(LOG_FILE)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    # Run main loop
    main()