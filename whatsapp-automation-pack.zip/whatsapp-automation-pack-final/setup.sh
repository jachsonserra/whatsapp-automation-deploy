#!/bin/bash
# WhatsApp Automation Pack - Setup Script

echo "🚀 WhatsApp Automation Pack Setup"
echo "================================="

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

if [[ $(echo "$python_version" | cut -d. -f1) -lt 3 ]] || [[ $(echo "$python_version" | cut -d. -f2) -lt 8 ]]; then
    echo "⚠️  Python 3.8+ is required. Please update Python."
    exit 1
fi

# Install required packages
echo "📦 Installing required Python packages..."
pip3 install --upgrade pip
pip3 install requests python-dateutil

# Create necessary directories
echo "📁 Creating directory structure..."
mkdir -p logs
mkdir -p reports
mkdir -p data

# Copy example config if config doesn't exist
if [ ! -f "whatsapp-config.json" ]; then
    echo "⚙️  Creating configuration file from example..."
    cp config/whatsapp-config-example.json whatsapp-config.json
    echo "✅ Created whatsapp-config.json"
    echo "⚠️  Please edit whatsapp-config.json with your business details"
fi

# Make scripts executable
echo "🔧 Making scripts executable..."
chmod +x scripts/*.py

# Create virtual environment (optional)
read -p "Create Python virtual environment? (y/n): " create_venv
if [[ $create_venv == "y" ]]; then
    echo "🐍 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
    echo "To activate: source venv/bin/activate"
fi

# Display next steps
echo ""
echo "🎉 Setup complete!"
echo ""
echo "NEXT STEPS:"
echo "1. Edit whatsapp-config.json with your business details"
echo "2. Review templates in templates/ directory"
echo "3. Read guides/GDPR-GUIDE.md for compliance"
echo "4. Test with: python3 scripts/auto-reply-gdpr.py"
echo ""
echo "For automation, add to crontab:"
echo "0 9 * * * cd $(pwd) && python3 scripts/report-generator.py"
echo ""
echo "Need help? Email: support@whatsflowpro.com"